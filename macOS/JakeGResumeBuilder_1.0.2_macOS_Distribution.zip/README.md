# JakeGResumeBuilder v1.0.2 - macOS Distribution

## Installation Instructions

### Quick Start
1. **Download** `JakeGResumeBuilder_v1.0.2.zip` from SourceForge
2. **Extract** the ZIP file (usually automatic with double-click)
3. **Move** the JakeGResumeBuilder app to your Applications folder
4. **Launch** the app or add it to the Dock
5. **Enjoy!** No additional dependencies required

### System Requirements
- macOS 10.13 or later
- Apple Silicon (M1/M2/M3) or Intel Mac
- ~50 MB disk space

### What's Included
- Fully standalone application - no Python installation needed
- All dependencies bundled inside the app
- Code-signed and optimized for security

### Features
- Create and manage resume projects
- Export to LaTeX, Word (.docx), and PDF formats
- Real-time preview
- Spell-checking capabilities
- Save projects as JSON files
- Customizable resume templates

### Troubleshooting

**"App is broken" or security warning:**
If you see a security dialog on first launch, this is normal for downloaded apps. Click "Open" or "Open Anyway" in System Preferences → Security & Privacy to proceed.

**App won't move to Applications:**
Right-click the app → Open With → Finder, then move it to Applications folder.

**App still shows as damaged:**
Run this in Terminal:
```bash
xattr -rd com.apple.quarantine ~/Applications/JakeGResumeBuilder*.app
```

### Support
For issues or feature requests, please visit the SourceForge project page.

### License
See the project repository for license information.

---
Built with PyInstaller for macOS - All dependencies included for a seamless experience.
